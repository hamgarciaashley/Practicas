import mysql.connector

HOST = "localhost"
USER = "root" 
PASSWORD = "" 
DATABASE = "tecnico"

def conectar():
    try:
    
        conexion = mysql.connector.connect(
            host=HOST,
            user=USER,
            password=PASSWORD,
            database=DATABASE,
            use_pure=True
        )
        
        
        if conexion.is_connected():
            print("Conexión exitosa a la base de datos")
            return conexion
            
    except Exception as e:
        print(f"Error al conectar a la base de datos: {e}")
        return None